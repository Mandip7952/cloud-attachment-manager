# ─────────────────────────────────────────
# IAM — Lambda execution role
# ─────────────────────────────────────────

resource "aws_iam_role" "lambda_exec" {
  name = "cloud-storage-lambda-exec-${var.env}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy" "lambda_policy" {
  name = "cloud-storage-lambda-policy-${var.env}"
  role = aws_iam_role.lambda_exec.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "S3FileAccess"
        Effect = "Allow"
        Action = [
          "s3:PutObject",
          "s3:GetObject",
          "s3:DeleteObject",
          "s3:HeadObject",
        ]
        Resource = "${aws_s3_bucket.storage.arn}/*"
      },
      {
        Sid    = "DynamoDBAccess"
        Effect = "Allow"
        Action = [
          "dynamodb:PutItem",
          "dynamodb:GetItem",
          "dynamodb:UpdateItem",
          "dynamodb:DeleteItem",
          "dynamodb:Query",
        ]
        Resource = [
          aws_dynamodb_table.files.arn,
          "${aws_dynamodb_table.files.arn}/index/*",
        ]
      },
      {
        Sid    = "CloudWatchLogs"
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents",
        ]
        Resource = "arn:aws:logs:*:*:*"
      },
    ]
  })
}

# ─────────────────────────────────────────
# Lambda zip archives (built locally)
# ─────────────────────────────────────────

data "archive_file" "upload" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/upload"
  output_path = "${path.module}/../dist/upload.zip"
}

data "archive_file" "download" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/download"
  output_path = "${path.module}/../dist/download.zip"
}

data "archive_file" "delete" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/delete"
  output_path = "${path.module}/../dist/delete.zip"
}

data "archive_file" "list_files" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/listFiles"
  output_path = "${path.module}/../dist/listFiles.zip"
}

data "archive_file" "confirm_upload" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda/confirmUpload"
  output_path = "${path.module}/../dist/confirmUpload.zip"
}

# ─────────────────────────────────────────
# Lambda functions
# ─────────────────────────────────────────

locals {
  common_env = {
    BUCKET_NAME     = aws_s3_bucket.storage.bucket
    TABLE_NAME      = aws_dynamodb_table.files.name
    ALLOWED_ORIGIN  = var.allowed_origin
    AWS_NODEJS_CONNECTION_REUSE_ENABLED = "1"
  }
}

resource "aws_lambda_function" "upload" {
  function_name    = "cloud-storage-upload-${var.env}"
  role             = aws_iam_role.lambda_exec.arn
  handler          = "index.handler"
  runtime          = "nodejs20.x"
  filename         = data.archive_file.upload.output_path
  source_code_hash = data.archive_file.upload.output_base64sha256
  memory_size      = var.lambda_memory_mb
  timeout          = var.lambda_timeout_seconds
  environment { variables = local.common_env }
}

resource "aws_lambda_function" "download" {
  function_name    = "cloud-storage-download-${var.env}"
  role             = aws_iam_role.lambda_exec.arn
  handler          = "index.handler"
  runtime          = "nodejs20.x"
  filename         = data.archive_file.download.output_path
  source_code_hash = data.archive_file.download.output_base64sha256
  memory_size      = var.lambda_memory_mb
  timeout          = var.lambda_timeout_seconds
  environment { variables = local.common_env }
}

resource "aws_lambda_function" "delete" {
  function_name    = "cloud-storage-delete-${var.env}"
  role             = aws_iam_role.lambda_exec.arn
  handler          = "index.handler"
  runtime          = "nodejs20.x"
  filename         = data.archive_file.delete.output_path
  source_code_hash = data.archive_file.delete.output_base64sha256
  memory_size      = var.lambda_memory_mb
  timeout          = var.lambda_timeout_seconds
  environment { variables = local.common_env }
}

resource "aws_lambda_function" "list_files" {
  function_name    = "cloud-storage-listFiles-${var.env}"
  role             = aws_iam_role.lambda_exec.arn
  handler          = "index.handler"
  runtime          = "nodejs20.x"
  filename         = data.archive_file.list_files.output_path
  source_code_hash = data.archive_file.list_files.output_base64sha256
  memory_size      = var.lambda_memory_mb
  timeout          = var.lambda_timeout_seconds
  environment { variables = local.common_env }
}

resource "aws_lambda_function" "confirm_upload" {
  function_name    = "cloud-storage-confirmUpload-${var.env}"
  role             = aws_iam_role.lambda_exec.arn
  handler          = "index.handler"
  runtime          = "nodejs20.x"
  filename         = data.archive_file.confirm_upload.output_path
  source_code_hash = data.archive_file.confirm_upload.output_base64sha256
  memory_size      = 128
  timeout          = 15
  environment { variables = local.common_env }
}

# CloudWatch log groups (14-day retention)
resource "aws_cloudwatch_log_group" "upload"         { name = "/aws/lambda/${aws_lambda_function.upload.function_name}"         ; retention_in_days = 14 }
resource "aws_cloudwatch_log_group" "download"       { name = "/aws/lambda/${aws_lambda_function.download.function_name}"       ; retention_in_days = 14 }
resource "aws_cloudwatch_log_group" "delete"         { name = "/aws/lambda/${aws_lambda_function.delete.function_name}"         ; retention_in_days = 14 }
resource "aws_cloudwatch_log_group" "list_files"     { name = "/aws/lambda/${aws_lambda_function.list_files.function_name}"     ; retention_in_days = 14 }
resource "aws_cloudwatch_log_group" "confirm_upload" { name = "/aws/lambda/${aws_lambda_function.confirm_upload.function_name}" ; retention_in_days = 14 }
