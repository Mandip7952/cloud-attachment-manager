# ─────────────────────────────────────────
# DynamoDB — File Metadata Table
# ─────────────────────────────────────────

resource "aws_dynamodb_table" "files" {
  name         = "FilesTable-${var.env}"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "userId"
  range_key    = "fileId"

  # Primary key attributes
  attribute {
    name = "userId"
    type = "S"
  }
  attribute {
    name = "fileId"
    type = "S"
  }
  attribute {
    name = "uploadedAt"
    type = "S"
  }

  # GSI: query all files for a user sorted by upload date
  global_secondary_index {
    name               = "UserFilesDateIndex"
    hash_key           = "userId"
    range_key          = "uploadedAt"
    projection_type    = "ALL"
  }

  # TTL: set expiresAt (Unix timestamp) on a record to auto-delete it
  ttl {
    attribute_name = "expiresAt"
    enabled        = true
  }

  point_in_time_recovery {
    enabled = true
  }

  deletion_protection_enabled = var.env == "prod"
}

# ─────────────────────────────────────────
# DynamoDB table schema (for reference)
# ─────────────────────────────────────────
#
# PK:  userId      (S)  — Cognito sub
# SK:  fileId      (S)  — UUID v4
#
# Attributes stored per item:
#   name        (S)  — original filename
#   size        (N)  — bytes (updated by confirmUpload)
#   type        (S)  — MIME type
#   s3Key       (S)  — S3 object key
#   status      (S)  — "pending" | "confirmed"
#   description (S)  — optional user description
#   tags        (SS) — string set of user tags
#   uploadedAt  (S)  — ISO-8601 timestamp
#   updatedAt   (S)  — ISO-8601 timestamp
#   expiresAt   (N)  — optional Unix timestamp for TTL
#
# GSI:
#   UserFilesDateIndex — userId (PK) + uploadedAt (SK) for date-sorted listing
