terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    archive = {
      source  = "hashicorp/archive"
      version = "~> 2.0"
    }
  }

  # Uncomment to use S3 backend for team use
  # backend "s3" {
  #   bucket = "your-terraform-state-bucket"
  #   key    = "cloud-storage/terraform.tfstate"
  #   region = "us-east-1"
  # }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "cloud-storage"
      Environment = var.env
      ManagedBy   = "terraform"
    }
  }
}

# ─────────────────────────────────────────
# Data sources
# ─────────────────────────────────────────
data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
