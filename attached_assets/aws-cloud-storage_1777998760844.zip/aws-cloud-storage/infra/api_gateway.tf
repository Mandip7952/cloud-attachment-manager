# ─────────────────────────────────────────
# API Gateway — REST API
# ─────────────────────────────────────────

resource "aws_api_gateway_rest_api" "storage" {
  name        = "cloud-storage-api-${var.env}"
  description = "Serverless cloud storage REST API"

  endpoint_configuration {
    types = ["REGIONAL"]
  }
}

# ─────────────────────────────────────────
# Cognito User Pool authorizer
# ─────────────────────────────────────────

resource "aws_cognito_user_pool" "main" {
  name = "cloud-storage-users-${var.env}"

  password_policy {
    minimum_length    = 8
    require_lowercase = true
    require_numbers   = true
    require_symbols   = false
    require_uppercase = true
  }

  auto_verified_attributes = ["email"]

  schema {
    name                = "email"
    attribute_data_type = "String"
    required            = true
    mutable             = true
  }
}

resource "aws_cognito_user_pool_client" "app" {
  name         = "cloud-storage-app-client"
  user_pool_id = aws_cognito_user_pool.main.id

  explicit_auth_flows = [
    "ALLOW_USER_SRP_AUTH",
    "ALLOW_REFRESH_TOKEN_AUTH",
  ]
}

resource "aws_api_gateway_authorizer" "cognito" {
  name          = "cognito-authorizer"
  rest_api_id   = aws_api_gateway_rest_api.storage.id
  type          = "COGNITO_USER_POOLS"
  provider_arns = [aws_cognito_user_pool.main.arn]
}

# ─────────────────────────────────────────
# /files resource
# ─────────────────────────────────────────

resource "aws_api_gateway_resource" "files" {
  rest_api_id = aws_api_gateway_rest_api.storage.id
  parent_id   = aws_api_gateway_rest_api.storage.root_resource_id
  path_part   = "files"
}

# POST /files → upload
resource "aws_api_gateway_method" "post_files" {
  rest_api_id   = aws_api_gateway_rest_api.storage.id
  resource_id   = aws_api_gateway_resource.files.id
  http_method   = "POST"
  authorization = "COGNITO_USER_POOLS"
  authorizer_id = aws_api_gateway_authorizer.cognito.id
}

resource "aws_api_gateway_integration" "post_files" {
  rest_api_id             = aws_api_gateway_rest_api.storage.id
  resource_id             = aws_api_gateway_resource.files.id
  http_method             = aws_api_gateway_method.post_files.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.upload.invoke_arn
}

# GET /files → list
resource "aws_api_gateway_method" "get_files" {
  rest_api_id   = aws_api_gateway_rest_api.storage.id
  resource_id   = aws_api_gateway_resource.files.id
  http_method   = "GET"
  authorization = "COGNITO_USER_POOLS"
  authorizer_id = aws_api_gateway_authorizer.cognito.id
}

resource "aws_api_gateway_integration" "get_files" {
  rest_api_id             = aws_api_gateway_rest_api.storage.id
  resource_id             = aws_api_gateway_resource.files.id
  http_method             = aws_api_gateway_method.get_files.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.list_files.invoke_arn
}

# ─────────────────────────────────────────
# /files/{fileId} resource
# ─────────────────────────────────────────

resource "aws_api_gateway_resource" "file_id" {
  rest_api_id = aws_api_gateway_rest_api.storage.id
  parent_id   = aws_api_gateway_resource.files.id
  path_part   = "{fileId}"
}

# GET /files/{fileId} → download
resource "aws_api_gateway_method" "get_file" {
  rest_api_id   = aws_api_gateway_rest_api.storage.id
  resource_id   = aws_api_gateway_resource.file_id.id
  http_method   = "GET"
  authorization = "COGNITO_USER_POOLS"
  authorizer_id = aws_api_gateway_authorizer.cognito.id
}

resource "aws_api_gateway_integration" "get_file" {
  rest_api_id             = aws_api_gateway_rest_api.storage.id
  resource_id             = aws_api_gateway_resource.file_id.id
  http_method             = aws_api_gateway_method.get_file.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.download.invoke_arn
}

# DELETE /files/{fileId} → delete
resource "aws_api_gateway_method" "delete_file" {
  rest_api_id   = aws_api_gateway_rest_api.storage.id
  resource_id   = aws_api_gateway_resource.file_id.id
  http_method   = "DELETE"
  authorization = "COGNITO_USER_POOLS"
  authorizer_id = aws_api_gateway_authorizer.cognito.id
}

resource "aws_api_gateway_integration" "delete_file" {
  rest_api_id             = aws_api_gateway_rest_api.storage.id
  resource_id             = aws_api_gateway_resource.file_id.id
  http_method             = aws_api_gateway_method.delete_file.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.delete.invoke_arn
}

# ─────────────────────────────────────────
# Lambda invoke permissions for API Gateway
# ─────────────────────────────────────────

locals {
  apigw_source_arn = "arn:aws:execute-api:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:${aws_api_gateway_rest_api.storage.id}/*"
}

resource "aws_lambda_permission" "apigw_upload"     { statement_id = "AllowAPIGWUpload"     ; action = "lambda:InvokeFunction" ; function_name = aws_lambda_function.upload.function_name     ; principal = "apigateway.amazonaws.com" ; source_arn = local.apigw_source_arn }
resource "aws_lambda_permission" "apigw_download"   { statement_id = "AllowAPIGWDownload"   ; action = "lambda:InvokeFunction" ; function_name = aws_lambda_function.download.function_name   ; principal = "apigateway.amazonaws.com" ; source_arn = local.apigw_source_arn }
resource "aws_lambda_permission" "apigw_delete"     { statement_id = "AllowAPIGWDelete"     ; action = "lambda:InvokeFunction" ; function_name = aws_lambda_function.delete.function_name     ; principal = "apigateway.amazonaws.com" ; source_arn = local.apigw_source_arn }
resource "aws_lambda_permission" "apigw_list_files" { statement_id = "AllowAPIGWListFiles"  ; action = "lambda:InvokeFunction" ; function_name = aws_lambda_function.list_files.function_name ; principal = "apigateway.amazonaws.com" ; source_arn = local.apigw_source_arn }

# ─────────────────────────────────────────
# Deployment & stage
# ─────────────────────────────────────────

resource "aws_api_gateway_deployment" "storage" {
  rest_api_id = aws_api_gateway_rest_api.storage.id

  triggers = {
    redeployment = sha1(jsonencode([
      aws_api_gateway_method.post_files,
      aws_api_gateway_method.get_files,
      aws_api_gateway_method.get_file,
      aws_api_gateway_method.delete_file,
      aws_api_gateway_integration.post_files,
      aws_api_gateway_integration.get_files,
      aws_api_gateway_integration.get_file,
      aws_api_gateway_integration.delete_file,
    ]))
  }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_api_gateway_stage" "storage" {
  deployment_id = aws_api_gateway_deployment.storage.id
  rest_api_id   = aws_api_gateway_rest_api.storage.id
  stage_name    = var.env

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_gateway.arn
  }
}

resource "aws_cloudwatch_log_group" "api_gateway" {
  name              = "/aws/apigateway/cloud-storage-${var.env}"
  retention_in_days = 14
}
