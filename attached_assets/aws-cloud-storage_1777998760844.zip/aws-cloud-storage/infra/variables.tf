variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "us-east-1"
}

variable "env" {
  description = "Deployment environment (dev, staging, prod)"
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "staging", "prod"], var.env)
    error_message = "env must be one of: dev, staging, prod"
  }
}

variable "allowed_origin" {
  description = "CORS allowed origin for API Gateway (e.g. https://yourdomain.com)"
  type        = string
  default     = "*"
}

variable "presigned_url_expiry_upload" {
  description = "Expiry seconds for pre-signed upload URLs"
  type        = number
  default     = 900 # 15 minutes
}

variable "presigned_url_expiry_download" {
  description = "Expiry seconds for pre-signed download URLs"
  type        = number
  default     = 3600 # 1 hour
}

variable "lambda_memory_mb" {
  description = "Memory (MB) for all Lambda functions"
  type        = number
  default     = 256
}

variable "lambda_timeout_seconds" {
  description = "Timeout (seconds) for all Lambda functions"
  type        = number
  default     = 30
}

variable "s3_glacier_transition_days" {
  description = "Days before objects are transitioned to Glacier"
  type        = number
  default     = 90
}
