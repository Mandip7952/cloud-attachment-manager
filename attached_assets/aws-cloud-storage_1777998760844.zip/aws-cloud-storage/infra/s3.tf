# ─────────────────────────────────────────
# S3 — File Storage Bucket
# ─────────────────────────────────────────

resource "aws_s3_bucket" "storage" {
  bucket = "cloud-storage-${var.env}-${data.aws_caller_identity.current.account_id}"

  lifecycle {
    prevent_destroy = false # set to true in prod
  }
}

resource "aws_s3_bucket_versioning" "storage" {
  bucket = aws_s3_bucket.storage.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "storage" {
  bucket = aws_s3_bucket.storage.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "storage" {
  bucket                  = aws_s3_bucket.storage.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_cors_configuration" "storage" {
  bucket = aws_s3_bucket.storage.id
  cors_rule {
    allowed_headers = ["*"]
    allowed_methods = ["GET", "PUT", "POST", "DELETE", "HEAD"]
    allowed_origins = [var.allowed_origin]
    expose_headers  = ["ETag", "Content-Length"]
    max_age_seconds = 3000
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "storage" {
  bucket = aws_s3_bucket.storage.id

  rule {
    id     = "archive-to-glacier"
    status = "Enabled"
    transition {
      days          = var.s3_glacier_transition_days
      storage_class = "GLACIER"
    }
    noncurrent_version_expiration {
      noncurrent_days = 30
    }
  }

  rule {
    id     = "abort-incomplete-multipart"
    status = "Enabled"
    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }
}

# Trigger confirmUpload Lambda on any new object
resource "aws_s3_bucket_notification" "storage" {
  bucket = aws_s3_bucket.storage.id

  lambda_function {
    lambda_function_arn = aws_lambda_function.confirm_upload.arn
    events              = ["s3:ObjectCreated:*"]
  }

  depends_on = [aws_lambda_permission.s3_invoke_confirm]
}

# Permission for S3 to invoke Lambda
resource "aws_lambda_permission" "s3_invoke_confirm" {
  statement_id  = "AllowS3Invoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.confirm_upload.function_name
  principal     = "s3.amazonaws.com"
  source_arn    = aws_s3_bucket.storage.arn
}
