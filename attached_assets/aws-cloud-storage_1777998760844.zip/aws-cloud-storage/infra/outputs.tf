output "api_base_url" {
  description = "Base URL of the REST API"
  value       = "${aws_api_gateway_stage.storage.invoke_url}"
}

output "s3_bucket_name" {
  description = "Name of the S3 storage bucket"
  value       = aws_s3_bucket.storage.bucket
}

output "dynamodb_table_name" {
  description = "Name of the DynamoDB metadata table"
  value       = aws_dynamodb_table.files.name
}

output "cognito_user_pool_id" {
  description = "Cognito User Pool ID"
  value       = aws_cognito_user_pool.main.id
}

output "cognito_client_id" {
  description = "Cognito App Client ID (use in your frontend)"
  value       = aws_cognito_user_pool_client.app.id
}

output "lambda_function_names" {
  description = "Names of all deployed Lambda functions"
  value = {
    upload         = aws_lambda_function.upload.function_name
    download       = aws_lambda_function.download.function_name
    delete         = aws_lambda_function.delete.function_name
    list_files     = aws_lambda_function.list_files.function_name
    confirm_upload = aws_lambda_function.confirm_upload.function_name
  }
}
