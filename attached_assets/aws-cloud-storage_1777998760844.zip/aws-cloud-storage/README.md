# ☁ AWS Serverless Cloud Storage System

A production-ready cloud file storage system built on **4 AWS managed services** — no servers to manage, no idle costs.

## Architecture

```
Browser / App
     │
     ▼
API Gateway  ──→  Lambda Functions  ──→  Amazon S3
  (REST API)        (Node.js 20.x)      (File storage)
  JWT auth              │
                        ▼
                    DynamoDB
                  (File metadata)
```

### The 4 Services

| Service | Role |
|---|---|
| **Amazon S3** | Stores all file objects (up to 5 GB each). Versioning, AES-256 encryption, Glacier archiving. |
| **AWS Lambda** | All business logic — upload, download, delete, list, confirm. Node.js 20.x, pay-per-invocation. |
| **API Gateway** | REST API with Cognito JWT auth, CORS, and rate limiting. 4 endpoints. |
| **DynamoDB** | File metadata store. Composite key (userId + fileId), GSI for date-sorted listing, TTL support. |

---

## Project Structure

```
aws-cloud-storage/
├── lambda/
│   ├── upload/          # POST /files — pre-signed PUT URL + DynamoDB write
│   ├── download/        # GET  /files/:id — pre-signed GET URL
│   ├── delete/          # DELETE /files/:id — S3 + DynamoDB delete
│   ├── listFiles/       # GET  /files — paginated list by userId
│   └── confirmUpload/   # S3 event trigger — marks upload as confirmed
├── infra/
│   ├── main.tf          # Provider config
│   ├── variables.tf     # All input variables
│   ├── s3.tf            # S3 bucket, encryption, lifecycle, CORS
│   ├── dynamodb.tf      # DynamoDB table + GSI
│   ├── lambda.tf        # All Lambda functions + IAM role
│   ├── api_gateway.tf   # REST API + Cognito authorizer + deployment
│   └── outputs.tf       # API URL, bucket name, Cognito IDs
├── frontend/
│   ├── index.html       # Demo UI (drag & drop, upload progress)
│   └── src/
│       └── storageClient.js  # JS SDK wrapping the REST API
├── docs/
│   └── api.md           # Full API reference
└── package.json
```

---

## Quick Start

### Prerequisites
- [Terraform](https://developer.hashicorp.com/terraform/install) ≥ 1.5
- [Node.js](https://nodejs.org/) ≥ 20
- AWS CLI configured (`aws configure`)

### 1. Install Lambda dependencies
```bash
npm run install:lambdas
```

### 2. Deploy to AWS
```bash
cd infra
terraform init
terraform apply -var="env=dev"
```

Terraform will output:
```
api_base_url         = "https://xxxx.execute-api.us-east-1.amazonaws.com/dev"
s3_bucket_name       = "cloud-storage-dev-123456789"
dynamodb_table_name  = "FilesTable-dev"
cognito_user_pool_id = "us-east-1_XXXXXXX"
cognito_client_id    = "XXXXXXXXXXXXXXXXXXXXXXXXXX"
```

### 3. Configure the frontend
Edit `frontend/index.html` and replace:
```js
const API_BASE_URL    = "https://xxxx.execute-api.us-east-1.amazonaws.com/dev";
const COGNITO_POOL_ID = "us-east-1_XXXXXXX";
const COGNITO_CLIENT  = "XXXXXXXXXXXXXXXXXXXXXXXXXX";
```

### 4. Open the demo
```bash
open frontend/index.html
# or serve locally:
npx serve frontend/
```

---

## API Reference

All endpoints require `Authorization: <Cognito JWT>` header.

### POST /files
Request a pre-signed upload URL.

**Request body:**
```json
{
  "name": "report.pdf",
  "size": 1048576,
  "type": "application/pdf",
  "description": "Q3 report",
  "tags": ["finance", "quarterly"]
}
```

**Response:**
```json
{
  "fileId": "uuid-v4",
  "uploadUrl": "https://s3.amazonaws.com/...",
  "expiresIn": 900
}
```

**Then PUT the file directly to S3:**
```bash
curl -X PUT "$uploadUrl" \
  -H "Content-Type: application/pdf" \
  --data-binary @report.pdf
```

---

### GET /files
List all files for the authenticated user.

**Query params:**
| Param | Description |
|---|---|
| `limit` | Max results (default 50, max 200) |
| `nextToken` | Pagination cursor from previous response |
| `type` | Filter by MIME type prefix (e.g. `image/`) |
| `tag` | Filter by tag |

**Response:**
```json
{
  "files": [
    {
      "fileId": "uuid",
      "name": "photo.jpg",
      "size": 204800,
      "type": "image/jpeg",
      "status": "confirmed",
      "uploadedAt": "2025-01-15T10:30:00Z"
    }
  ],
  "count": 1,
  "nextToken": null
}
```

---

### GET /files/:fileId
Get a pre-signed download URL (valid 1 hour).

**Response:**
```json
{
  "fileId": "uuid",
  "name": "photo.jpg",
  "downloadUrl": "https://s3.amazonaws.com/...",
  "expiresIn": 3600
}
```

---

### DELETE /files/:fileId
Delete a file from S3 and remove its metadata from DynamoDB.

**Response:**
```json
{ "message": "File deleted successfully", "fileId": "uuid" }
```

---

## JavaScript SDK

```js
import { CloudStorageClient } from "./frontend/src/storageClient.js";

const client = new CloudStorageClient({
  apiBaseUrl: "https://xxxx.execute-api.us-east-1.amazonaws.com/dev",
  getToken: async () => "your-cognito-jwt",
});

// Upload with progress
const { fileId } = await client.upload(file, {
  description: "My file",
  tags: ["docs"],
  onProgress: (pct) => console.log(`${pct}%`),
});

// List files
const { files } = await client.listFiles({ limit: 20, type: "image/" });

// Download (triggers browser save dialog)
await client.download(fileId);

// Delete
await client.deleteFile(fileId);
```

---

## Upload Flow (how it works)

```
Client                   API Gateway         Lambda           S3           DynamoDB
  │                           │                 │              │               │
  │── POST /files ───────────▶│                 │              │               │
  │   { name, size, type }    │── invoke ───────▶│              │               │
  │                           │                 │── PutItemCmd ─────────────────▶│
  │                           │                 │              │  write pending  │
  │◀── { fileId, uploadUrl } ─│                 │              │               │
  │                           │                 │              │               │
  │── PUT file ────────────────────────────────────────────────▶│               │
  │   (directly to S3)        │                 │              │               │
  │                           │                 │              │── event ───────▶│
  │                           │                 │◀─────────────│  confirmUpload  │
  │                           │                 │── UpdateItem ─────────────────▶│
  │                           │                 │              │  status=confirmed│
```

---

## Cost Estimate (light workload)

| Service | Usage | Monthly Cost |
|---|---|---|
| S3 | 10 GB storage + 10K requests | ~$0.25 |
| Lambda | 50K invocations × 256 MB | ~$0.01 |
| API Gateway | 50K requests | ~$0.18 |
| DynamoDB | On-demand, 50K r/w | ~$0.13 |
| **Total** | | **~$0.57/mo** |

---

## Destroy

```bash
cd infra && terraform destroy
```

---

## License
MIT
