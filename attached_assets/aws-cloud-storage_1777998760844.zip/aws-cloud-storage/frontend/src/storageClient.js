// frontend/src/storageClient.js
// Simple JS SDK that wraps the Cloud Storage REST API
// Works in any browser or Node.js environment

export class CloudStorageClient {
  /**
   * @param {Object} config
   * @param {string} config.apiBaseUrl   — API Gateway base URL (from Terraform output)
   * @param {string} config.getToken     — async function that returns a valid Cognito JWT
   */
  constructor({ apiBaseUrl, getToken }) {
    this.baseUrl  = apiBaseUrl.replace(/\/$/, "");
    this.getToken = getToken;
  }

  async #headers() {
    const token = await this.getToken();
    return {
      "Authorization": token,
      "Content-Type":  "application/json",
    };
  }

  /**
   * Upload a File or Blob object.
   * 1. Requests a pre-signed URL from the API
   * 2. PUTs the file directly to S3
   * 3. Returns the fileId for future operations
   *
   * @param {File|Blob} file
   * @param {Object}    [options]
   * @param {string}    [options.description]
   * @param {string[]}  [options.tags]
   * @param {Function}  [options.onProgress]  — callback(percent: number)
   * @returns {Promise<{ fileId: string }>}
   */
  async upload(file, { description = "", tags = [], onProgress } = {}) {
    // Step 1: Get pre-signed upload URL
    const res = await fetch(`${this.baseUrl}/files`, {
      method:  "POST",
      headers: await this.#headers(),
      body: JSON.stringify({
        name:  file.name || "untitled",
        size:  file.size,
        type:  file.type || "application/octet-stream",
        description,
        tags,
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(`Failed to get upload URL: ${err.error || res.statusText}`);
    }

    const { fileId, uploadUrl } = await res.json();

    // Step 2: PUT file directly to S3 (with optional progress tracking)
    await this.#putToS3(uploadUrl, file, file.type, onProgress);

    return { fileId, name: file.name, size: file.size };
  }

  async #putToS3(url, body, contentType, onProgress) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("PUT", url);
      xhr.setRequestHeader("Content-Type", contentType);

      if (onProgress) {
        xhr.upload.addEventListener("progress", (e) => {
          if (e.lengthComputable) {
            onProgress(Math.round((e.loaded / e.total) * 100));
          }
        });
      }

      xhr.onload  = () => (xhr.status < 300 ? resolve() : reject(new Error(`S3 PUT failed: ${xhr.status}`)));
      xhr.onerror = () => reject(new Error("S3 PUT network error"));
      xhr.send(body);
    });
  }

  /**
   * Get a pre-signed download URL for a file.
   * @param {string} fileId
   * @returns {Promise<{ downloadUrl: string, name: string, size: number, type: string }>}
   */
  async getDownloadUrl(fileId) {
    const res = await fetch(`${this.baseUrl}/files/${fileId}`, {
      headers: await this.#headers(),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(`Failed to get download URL: ${err.error || res.statusText}`);
    }

    return res.json();
  }

  /**
   * Download a file directly (triggers browser save dialog).
   * @param {string} fileId
   */
  async download(fileId) {
    const { downloadUrl, name } = await this.getDownloadUrl(fileId);
    const a = document.createElement("a");
    a.href     = downloadUrl;
    a.download = name;
    a.click();
  }

  /**
   * List all files for the authenticated user.
   * @param {Object} [options]
   * @param {number} [options.limit]      — max results (default 50, max 200)
   * @param {string} [options.nextToken]  — pagination cursor
   * @param {string} [options.type]       — filter by MIME type prefix (e.g. "image/")
   * @param {string} [options.tag]        — filter by tag
   * @returns {Promise<{ files: Array, nextToken: string|null }>}
   */
  async listFiles({ limit = 50, nextToken, type, tag } = {}) {
    const params = new URLSearchParams();
    if (limit)     params.set("limit",     limit);
    if (nextToken) params.set("nextToken", nextToken);
    if (type)      params.set("type",      type);
    if (tag)       params.set("tag",       tag);

    const res = await fetch(`${this.baseUrl}/files?${params}`, {
      headers: await this.#headers(),
    });

    if (!res.ok) throw new Error(`Failed to list files: ${res.statusText}`);
    return res.json();
  }

  /**
   * Delete a file from S3 and remove its metadata.
   * @param {string} fileId
   */
  async deleteFile(fileId) {
    const res = await fetch(`${this.baseUrl}/files/${fileId}`, {
      method:  "DELETE",
      headers: await this.#headers(),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(`Failed to delete file: ${err.error || res.statusText}`);
    }

    return res.json();
  }
}
