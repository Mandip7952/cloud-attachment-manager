// lambda/download/index.js
// GET /files/:fileId — returns a pre-signed S3 GET URL for secure file download

const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");

const s3  = new S3Client({ region: process.env.AWS_REGION });
const ddb = new DynamoDBClient({ region: process.env.AWS_REGION });

exports.handler = async (event) => {
  try {
    const userId = event.requestContext?.authorizer?.claims?.sub;
    if (!userId) return response(401, { error: "Unauthorized" });

    const fileId = event.pathParameters?.fileId;
    if (!fileId) return response(400, { error: "fileId path parameter is required" });

    // 1. Fetch file metadata from DynamoDB
    const { Item } = await ddb.send(new GetItemCommand({
      TableName: process.env.TABLE_NAME,
      Key: {
        userId: { S: userId },
        fileId: { S: fileId },
      },
    }));

    if (!Item) {
      return response(404, { error: "File not found" });
    }

    if (Item.status.S !== "confirmed") {
      return response(409, { error: "File upload is not yet confirmed", status: Item.status.S });
    }

    // 2. Generate pre-signed GET URL (1-hour expiry)
    const getCmd = new GetObjectCommand({
      Bucket:                     process.env.BUCKET_NAME,
      Key:                        Item.s3Key.S,
      ResponseContentDisposition: `attachment; filename="${Item.name.S}"`,
      ResponseContentType:        Item.type.S,
    });
    const downloadUrl = await getSignedUrl(s3, getCmd, { expiresIn: 3600 });

    return response(200, {
      fileId,
      name:        Item.name.S,
      size:        Number(Item.size.N),
      type:        Item.type.S,
      description: Item.description?.S || "",
      tags:        Item.tags?.SS?.filter(t => t !== "_none") || [],
      uploadedAt:  Item.uploadedAt.S,
      downloadUrl,
      expiresIn:   3600,
    });

  } catch (err) {
    console.error("downloadFile error:", err);
    return response(500, { error: "Internal server error" });
  }
};

function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGIN || "*",
      "Access-Control-Allow-Headers": "Authorization,Content-Type",
    },
    body: JSON.stringify(body),
  };
}
