// lambda/confirmUpload/index.js
// Triggered by S3 PutObject event — marks the DynamoDB record as "confirmed"

const { DynamoDBClient, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");

const ddb = new DynamoDBClient({ region: process.env.AWS_REGION });

exports.handler = async (event) => {
  const results = [];

  for (const record of event.Records) {
    const s3Key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));
    const size  = record.s3.object.size;

    try {
      // s3Key format: {userId}/{fileId}/{filename}
      const parts = s3Key.split("/");
      if (parts.length < 3) {
        console.warn(`Unexpected s3Key format: ${s3Key}`);
        continue;
      }
      const [userId, fileId] = parts;

      await ddb.send(new UpdateItemCommand({
        TableName: process.env.TABLE_NAME,
        Key: {
          userId: { S: userId },
          fileId: { S: fileId },
        },
        UpdateExpression: "SET #status = :confirmed, size = :size, updatedAt = :now",
        ExpressionAttributeNames: { "#status": "status" },
        ExpressionAttributeValues: {
          ":confirmed": { S: "confirmed" },
          ":pending":   { S: "pending" },
          ":size":      { N: String(size) },
          ":now":       { S: new Date().toISOString() },
        },
        ConditionExpression: "#status = :pending", // idempotent — only update if pending
      }));

      console.log(`Confirmed upload: userId=${userId} fileId=${fileId} size=${size}`);
      results.push({ s3Key, status: "confirmed" });

    } catch (err) {
      // ConditionalCheckFailedException = already confirmed (idempotent), that's fine
      if (err.name === "ConditionalCheckFailedException") {
        console.log(`Already confirmed: ${s3Key}`);
        results.push({ s3Key, status: "already_confirmed" });
      } else {
        console.error(`Failed to confirm ${s3Key}:`, err);
        results.push({ s3Key, status: "error", error: err.message });
      }
    }
  }

  return { results };
};
