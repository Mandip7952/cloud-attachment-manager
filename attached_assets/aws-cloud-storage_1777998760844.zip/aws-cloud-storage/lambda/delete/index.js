// lambda/delete/index.js
// DELETE /files/:fileId — removes the S3 object and DynamoDB metadata record

const { S3Client, DeleteObjectCommand } = require("@aws-sdk/client-s3");
const { DynamoDBClient, GetItemCommand, DeleteItemCommand } = require("@aws-sdk/client-dynamodb");

const s3  = new S3Client({ region: process.env.AWS_REGION });
const ddb = new DynamoDBClient({ region: process.env.AWS_REGION });

exports.handler = async (event) => {
  try {
    const userId = event.requestContext?.authorizer?.claims?.sub;
    if (!userId) return response(401, { error: "Unauthorized" });

    const fileId = event.pathParameters?.fileId;
    if (!fileId) return response(400, { error: "fileId path parameter is required" });

    // 1. Fetch metadata to get the S3 key (and verify ownership)
    const { Item } = await ddb.send(new GetItemCommand({
      TableName: process.env.TABLE_NAME,
      Key: {
        userId: { S: userId },
        fileId: { S: fileId },
      },
    }));

    if (!Item) {
      return response(404, { error: "File not found" });
    }

    const s3Key = Item.s3Key.S;

    // 2. Delete from S3
    await s3.send(new DeleteObjectCommand({
      Bucket: process.env.BUCKET_NAME,
      Key:    s3Key,
    }));

    // 3. Delete metadata from DynamoDB
    await ddb.send(new DeleteItemCommand({
      TableName: process.env.TABLE_NAME,
      Key: {
        userId: { S: userId },
        fileId: { S: fileId },
      },
    }));

    console.log(`Deleted file ${fileId} (s3Key: ${s3Key}) for user ${userId}`);

    return response(200, {
      message: "File deleted successfully",
      fileId,
    });

  } catch (err) {
    console.error("deleteFile error:", err);
    return response(500, { error: "Internal server error" });
  }
};

function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGIN || "*",
      "Access-Control-Allow-Headers": "Authorization,Content-Type",
    },
    body: JSON.stringify(body),
  };
}
