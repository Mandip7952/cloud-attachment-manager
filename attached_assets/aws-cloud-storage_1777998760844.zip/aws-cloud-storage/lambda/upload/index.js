// lambda/upload/index.js
// POST /files — generates a pre-signed S3 PUT URL and writes file metadata to DynamoDB

const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");
const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { v4: uuidv4 } = require("uuid");

const s3  = new S3Client({ region: process.env.AWS_REGION });
const ddb = new DynamoDBClient({ region: process.env.AWS_REGION });

const ALLOWED_TYPES = [
  "image/jpeg", "image/png", "image/gif", "image/webp",
  "application/pdf", "text/plain", "text/csv",
  "application/zip", "video/mp4", "audio/mpeg",
];
const MAX_SIZE_BYTES = 5 * 1024 * 1024 * 1024; // 5 GB

exports.handler = async (event) => {
  try {
    // Extract authenticated userId from Cognito JWT claims
    const userId = event.requestContext?.authorizer?.claims?.sub;
    if (!userId) {
      return response(401, { error: "Unauthorized" });
    }

    const body = JSON.parse(event.body || "{}");
    const { name, size, type, description = "", tags = [] } = body;

    // Validate inputs
    if (!name || !size || !type) {
      return response(400, { error: "name, size, and type are required" });
    }
    if (!ALLOWED_TYPES.includes(type)) {
      return response(400, { error: `File type '${type}' is not allowed` });
    }
    if (size > MAX_SIZE_BYTES) {
      return response(400, { error: "File exceeds 5 GB maximum size" });
    }

    const fileId    = uuidv4();
    const s3Key     = `${userId}/${fileId}/${name}`;
    const now       = new Date().toISOString();

    // 1. Generate pre-signed PUT URL (15-minute expiry)
    const putCmd = new PutObjectCommand({
      Bucket:             process.env.BUCKET_NAME,
      Key:                s3Key,
      ContentType:        type,
      ContentLength:      size,
      ServerSideEncryption: "AES256",
      Metadata: {
        userId,
        fileId,
        originalName: name,
      },
    });
    const uploadUrl = await getSignedUrl(s3, putCmd, { expiresIn: 900 });

    // 2. Write metadata record to DynamoDB (status = "pending" until S3 confirms)
    await ddb.send(new PutItemCommand({
      TableName: process.env.TABLE_NAME,
      Item: {
        userId:      { S: userId },
        fileId:      { S: fileId },
        name:        { S: name },
        size:        { N: String(size) },
        type:        { S: type },
        s3Key:       { S: s3Key },
        status:      { S: "pending" },
        description: { S: description },
        tags:        { SS: tags.length ? tags : ["_none"] },
        uploadedAt:  { S: now },
        updatedAt:   { S: now },
      },
      ConditionExpression: "attribute_not_exists(fileId)", // prevent duplicates
    }));

    return response(200, {
      fileId,
      uploadUrl,
      expiresIn: 900,
      message: "Upload URL generated. PUT your file to uploadUrl, then call GET /files/:fileId to confirm.",
    });

  } catch (err) {
    console.error("uploadFile error:", err);
    return response(500, { error: "Internal server error" });
  }
};

function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGIN || "*",
      "Access-Control-Allow-Headers": "Authorization,Content-Type",
    },
    body: JSON.stringify(body),
  };
}
