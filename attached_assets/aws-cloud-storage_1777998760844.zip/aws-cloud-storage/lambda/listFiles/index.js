// lambda/listFiles/index.js
// GET /files — list all files for the authenticated user, sorted by uploadedAt descending

const { DynamoDBClient, QueryCommand } = require("@aws-sdk/client-dynamodb");

const ddb = new DynamoDBClient({ region: process.env.AWS_REGION });

exports.handler = async (event) => {
  try {
    const userId = event.requestContext?.authorizer?.claims?.sub;
    if (!userId) return response(401, { error: "Unauthorized" });

    const qs          = event.queryStringParameters || {};
    const limit       = Math.min(parseInt(qs.limit  || "50"), 200);
    const startKey    = qs.nextToken ? JSON.parse(Buffer.from(qs.nextToken, "base64").toString()) : undefined;
    const filterType  = qs.type;  // optional filter by MIME type prefix e.g. "image/"
    const filterTag   = qs.tag;   // optional filter by tag

    // Query DynamoDB using GSI (sorted by uploadedAt DESC)
    const params = {
      TableName:                process.env.TABLE_NAME,
      IndexName:                "UserFilesDateIndex",
      KeyConditionExpression:   "userId = :uid",
      ExpressionAttributeValues: {
        ":uid": { S: userId },
      },
      ScanIndexForward: false,  // newest first
      Limit:            limit,
    };

    // Optional filter expressions
    const filters = [];
    if (filterType) {
      params.ExpressionAttributeValues[":typePrefix"] = { S: filterType };
      filters.push("begins_with(#type, :typePrefix)");
      params.ExpressionAttributeNames = { "#type": "type" };
    }
    if (filterTag) {
      params.ExpressionAttributeValues[":tag"] = { S: filterTag };
      filters.push("contains(tags, :tag)");
    }
    // Only return confirmed uploads
    params.ExpressionAttributeValues[":confirmed"] = { S: "confirmed" };
    filters.push("#status = :confirmed");
    params.ExpressionAttributeNames = {
      ...(params.ExpressionAttributeNames || {}),
      "#status": "status",
    };

    if (filters.length) {
      params.FilterExpression = filters.join(" AND ");
    }

    if (startKey) {
      params.ExclusiveStartKey = startKey;
    }

    const result = await ddb.send(new QueryCommand(params));

    const files = (result.Items || []).map(item => ({
      fileId:      item.fileId.S,
      name:        item.name.S,
      size:        Number(item.size.N),
      type:        item.type.S,
      description: item.description?.S || "",
      tags:        item.tags?.SS?.filter(t => t !== "_none") || [],
      status:      item.status.S,
      uploadedAt:  item.uploadedAt.S,
      updatedAt:   item.updatedAt?.S || item.uploadedAt.S,
    }));

    const nextToken = result.LastEvaluatedKey
      ? Buffer.from(JSON.stringify(result.LastEvaluatedKey)).toString("base64")
      : null;

    return response(200, {
      files,
      count:     files.length,
      nextToken,
    });

  } catch (err) {
    console.error("listFiles error:", err);
    return response(500, { error: "Internal server error" });
  }
};

function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGIN || "*",
      "Access-Control-Allow-Headers": "Authorization,Content-Type",
    },
    body: JSON.stringify(body),
  };
}
